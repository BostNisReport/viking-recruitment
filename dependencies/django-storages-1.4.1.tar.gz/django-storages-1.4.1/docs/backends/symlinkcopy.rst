Symlink or copy
===============

Stores symlinks to files instead of actual files whenever possible

When a file that's being saved is currently stored in the symlink_within directory, then symlink the file. Otherwise, copy the file.
