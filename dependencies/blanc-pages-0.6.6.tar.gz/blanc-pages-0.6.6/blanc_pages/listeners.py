# -*- coding: utf-8 -*-

from django.db.models.signals import post_save


def pageversion_update(sender, instance, raw=False, **kwargs):
    if raw:
        return

    page = instance.page

    # Page save method recalculates the unpublished pages
    page.save()


post_save.connect(pageversion_update, sender='pages.PageVersion')

