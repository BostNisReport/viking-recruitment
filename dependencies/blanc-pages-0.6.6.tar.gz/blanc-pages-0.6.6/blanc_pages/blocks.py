import warnings
from blanc_pages.models.blocks import BaseBlock  # noqa


warnings.warn(
    "BaseBlock has been moved to blanc_pages.models.blocks ",
    DeprecationWarning, stacklevel=2)
