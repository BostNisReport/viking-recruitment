# -*- coding: utf-8 -*-

from django.conf import settings
from django.contrib.auth.decorators import user_passes_test
from django.core.urlresolvers import reverse
from django.db.models import Q
from django.http import Http404, HttpResponsePermanentRedirect, HttpResponseRedirect
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from django.views.decorators.csrf import csrf_protect

from .exceptions import BlancPageRedirectException
from .models.pages import Page
from .page import BlancPage


# Called from blancpage.middleware.BlancpageFallbackMiddleware
# Mostly a copy of the django.contrib.flatpages implementation
def blancpage(request, url):

    PAGE_LOGIN_PERMS = getattr(settings, 'BLANC_PAGES_LOGIN_PERMS', False)

    if not url.startswith('/'):
        url = '/' + url

    page_opts = Page._meta.app_label, Page._meta.model_name

    try:
        page = get_object_or_404(Page.objects.select_related('current_version'), url__exact=url)
    except Http404:
        if not url.endswith('/') and settings.APPEND_SLASH:
            url += '/'
            page = get_object_or_404(Page, url__exact=url)
            return HttpResponsePermanentRedirect('%s/' % request.path)
        else:
            raise

    # Unpublished page
    # - Editors get a page not published
    # - Other users get a 404
    if not page.published or not page.current_version:
        if request.user.has_perm('%s.edit_%s' % page_opts):
            return render_page_unpublished(request, page)
        else:
            raise Http404

    # Page with login required
    if page.login_required:
        def can_view_page(user):
            if PAGE_LOGIN_PERMS:
                # Need the 'view_protected_page' permission to access this page
                return (user.has_perm('%s.view_protected_%s' % page_opts) or
                        user.has_perm('%s.view_protected_%s' % page_opts, obj=page))
            else:
                # Any authenticated user will do
                return user.is_authenticated()

        @user_passes_test(can_view_page)
        def view_protected_page(request):
            return render_page(request, page, page.current_version)

        # Pass it to the protected version to see if the user can view the page
        return view_protected_page(request)

    return render_page(request, page, page.current_version)


@csrf_protect
def render_page(request, page, page_version, edit=False):
    blanc_page = BlancPage(page_version, edit, request)

    try:
        response = render_to_response(page_version.template_name, {
            'blanc_page': blanc_page,
        }, context_instance=RequestContext(request))
    except BlancPageRedirectException as e:
        return HttpResponseRedirect(e.url)

    return response


@csrf_protect
def render_page_unpublished(request, page):
    info = page._meta.app_label, page._meta.model_name

    try:
        # Find the latest version a user has access to
        page_version = page.pageversion_set.exclude(~Q(owner=request.user), version_number__isnull=True)[0]
        page_url = reverse('admin:%s_%s_version' % info, kwargs={'pk': page_version.pk})
    except IndexError:
        # No version available, go edit a new template
        page_version = None
        page_url = reverse('admin:%s_%s_template' % info, kwargs={'page_pk': page.pk})

    response = render_to_response('admin/blanc_pages/page_unpublished.html', {
        'page': page,
        'page_version': page_version,
        'page_url': page_url,
    }, context_instance=RequestContext(request))

    return response
