from django.apps import AppConfig


class BlancPagesConfig(AppConfig):
    name = 'blanc_pages'
    label = 'pages'

    def ready(self):
        super(BlancPagesConfig, self).ready()
        from . import listeners  # noqa
