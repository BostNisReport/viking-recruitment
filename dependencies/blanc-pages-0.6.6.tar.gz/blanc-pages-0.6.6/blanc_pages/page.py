# -*- coding: utf-8 -*-

from django.db.models import Q
from django.conf import settings
from django.core.urlresolvers import reverse, get_mod_func
from django.forms.widgets import Select
from django.utils.encoding import force_text
from django.utils.functional import cached_property
from django.utils.text import capfirst
from django.template.defaultfilters import slugify
from django.template.loader import render_to_string
from django.utils import six
from blanc_pages import get_template, get_templates
from blanc_pages.exceptions import BlancPageColumnException
from blanc_pages.models.pages import Page, PageVersion, ContentBlock
from blanc_pages.widgets import AddBlockSelect, ChooseColumnSelect, MoveBlockSelect
from collections import defaultdict
from importlib import import_module


# If no other settings are provided, just show HTML as a quick add block
BLANC_PAGES_DEFAULT_BLOCKS = (
    ('pages.HTML', 'HTML'),
)


class BlancPageBlock(object):
    def __init__(self, content_block, column, block_number):
        self.content_block = content_block
        self.block = content_block.content_object
        self.column = column
        self.blanc_page = column.blanc_page
        self.block_number = block_number

    def render(self, rerender):
        # Add some classes to the block to help style it
        block_classes = self.css_classes()

        # Render the block
        mod_name, func_name = get_mod_func(self.block.render_function)
        block_view = getattr(import_module(mod_name), func_name)
        self.html = block_view(
            self.block, self.blanc_page.request, rerender, self.content_block, block_classes)

    def css_classes(self):
        # Add some classes to the block to help style it
        block_classes = ['blanc_page_blocktype_%s' % (self.block._meta.model_name,)]

        if self.block_number == 1:
            block_classes.append('blanc_page_block_first')

        if self.block_number % 2 == 0:
            block_classes.append('blanc_page_block blanc_page_block_even')
        else:
            block_classes.append('blanc_page_block blanc_page_block_odd')

        if self.block_number == len(self.column.blocks):
            block_classes.append('blanc_page_block_last')

        return block_classes

    def block_type(self):
        return capfirst(force_text(self.content_block.content_object._meta.verbose_name))

    def edit_url(self):
        opts = self.block._meta.app_label, self.block._meta.model_name
        return reverse('block_admin:%s_%s_change' % opts, args=(self.block.pk,))

    def choose_column_widget(self):
        column_list = six.iterkeys(self.blanc_page.layout.columns)
        choose_column_options = ((x, x) for x in sorted(column_list))

        widget = ChooseColumnSelect(attrs={
            'class': 'blanc-pages-move-column-select',
        }, choices=choose_column_options)

        return widget.render(name='', value=self.column.name)

    def move_block_widget(self):
        from blanc_pages.forms import MoveBlockForm

        move_options = []

        if self.block_number != 1:
            move_options.extend((
                (MoveBlockForm.MOVE_TOP, 'To top'),
                (MoveBlockForm.MOVE_UP, 'Up'),
            ))

        if self.block_number != len(self.column.blocks):
            move_options.extend((
                (MoveBlockForm.MOVE_DOWN, 'Down'),
                (MoveBlockForm.MOVE_BOTTOM, 'To bottom'),
            ))

        widget = MoveBlockSelect(attrs={
            'class': 'blanc-pages-move-block-select',
        }, choices=move_options)

        return widget.render(name='', value=None)


class BlancPageColumn(object):
    def __init__(self, name, blanc_page, content_blocks):
        self.name = name
        self.blanc_page = blanc_page
        self.blocks = []

        # Build up a list of page blocks
        for block_num, content_block in enumerate(content_blocks, start=1):
            block = BlancPageBlock(content_block, self, block_num)
            self.blocks.append(block)

    def render(self, edit_mode=False, rerender=False):
        # Render all the blocks
        for block in self.blocks:
            block.render(rerender)

        # Column structure
        column_template = 'blanc_pages/include/column.html'
        column_context = {
            'blocks': self.blocks,
            'column_slug': slugify(self.name),
        }

        if edit_mode:
            # Edit mode has a more complex template
            column_template = 'blanc_pages/include/column_edit.html'

            column_context.update({
                'blanc_page': self.blanc_page,
                'column_name': self.name,
                'default_blocks': getattr(settings, 'BLANC_PAGES_DEFAULT_BLOCKS', BLANC_PAGES_DEFAULT_BLOCKS),
                'add_block_widget': self.add_block_widget(),
            })

        return render_to_string(column_template, column_context)

    def add_block_widget(self):
        widget = AddBlockSelect(attrs={
            'class': 'blanc-pages-add-block-select',
        }, choices=self.add_block_options())

        return widget.render(name='', value=None)

    def add_block_options(self):
        from blanc_pages import block_admin

        block_choices = []

        # Group all block by category
        for category in sorted(block_admin.site.block_list):
            category_blocks = block_admin.site.block_list[category]
            category_choices = (('%s.%s' % (x._meta.app_label, x._meta.object_name),
                                 capfirst(force_text(x._meta.verbose_name))) for x in
                                category_blocks)
            category_choices = sorted(category_choices, key=lambda x: x[1])
            block_choices.append((category, category_choices))

        return block_choices


class BlancPage(object):
    """
    A page object which contains all of the data necessary to render a blanc
    page template.
    """

    saved_pages = None
    unsaved_pages = None
    comments = None
    columns = None

    def __init__(self, page_version, edit_mode=False, request=None):
        self.version = page_version
        self.page = page_version.page
        self.edit_mode = edit_mode
        self.request = request

        if request is None:
            self.user = None
        else:
            self.user = request.user

        self.layout = get_template(page_version.template_name)
        self.opts = Page._meta

        # Only show controls to logged in users
        if self.user is not None:
            self.show_controls = self.user.has_perm(self.opts.app_label + '.edit_page')
        else:
            self.show_controls = False

        # Fetch all content blocks in one go
        self.column_blocks = defaultdict(list)

        for i in ContentBlock.objects.filter(page_version=self.version):
            self.column_blocks[i.column].append(i)

    def owner_versions(self):
        # Fiddly queryset which hides unsaved versions of other users
        return PageVersion.objects.select_related().filter(page=self.page).exclude(
            ~Q(owner=self.user), version_number__isnull=True
        )

    def all_versions(self):
        return self.owner_versions().order_by('-modified')

    @cached_property
    def previous_version(self):
        try:
            return self.owner_versions().filter(modified__lt=self.version.modified).order_by('-modified')[0]
        except IndexError:
            return None

    @cached_property
    def next_version(self):
        try:
            return self.owner_versions().filter(modified__gt=self.version.modified).order_by('modified')[0]
        except IndexError:
            return None

    def render_column(self, column_name, rerender=False):
        # Ensure this is a valid column, otherwise we could end up confused as to why no content
        # gets pulled in
        if column_name not in self.layout.columns:
            raise BlancPageColumnException(
                u'Column name "{}" is not a valid column for this template'.format(column_name)
            )

        column = BlancPageColumn(
            name=column_name, blanc_page=self, content_blocks=self.column_blocks[column_name]
        )
        return column.render(self.edit_mode, rerender)

    def change_template_widget(self):
        change_template_options = sorted(get_templates(), key=lambda x: x[1])

        widget = Select(attrs={
            'id': 'id_template_name',
        }, choices=change_template_options)

        return widget.render(name='template_name', value=self.layout.template_name)
