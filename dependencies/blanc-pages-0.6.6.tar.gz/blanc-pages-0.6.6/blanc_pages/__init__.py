# -*- coding: utf-8 -*-

from django.utils import six


default_app_config = 'blanc_pages.apps.BlancPagesConfig'


class BlancPageLayout(object):
    """
    Base Layout object used to store template structure details.
    """

    template_name = 'blanc_pages/default.html'
    title = None
    columns = ()


def register_template(template_obj):
    templates[template_obj.template_name] = template_obj


def get_templates():
    for template_obj in six.itervalues(templates):
        yield (template_obj.template_name, template_obj.title)


def get_template(template_name):
    return templates[template_name]


templates = {}
