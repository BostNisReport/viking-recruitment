# -*- coding: utf-8 -*-

import os

from django.utils.crypto import get_random_string

DEBUG = True
TEMPLATE_DEBUG = True

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': 'test',
    }
}

CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
    }
}

SITE_ID = 1

STATIC_URL = '/static/'

SECRET_KEY = get_random_string(length=50)

ROOT_URLCONF = ''

MIDDLEWARE_CLASSES = (
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.auth.middleware.SessionAuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'blanc_pages.middleware.BlancpageFallbackMiddleware',
)

INSTALLED_APPS = (
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.sites',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.admin',
    'blanc_pages.tests.sample',
    'mptt',
    'blanc_pages',
    'blanc_pages.tests.sampleblocks',
)

USE_TZ = True

APPEND_SLASH = True

BLANC_PAGES_LOGIN_PERMS = True

