# -*- coding: utf-8 -*-

from django.contrib.auth import get_user_model
from django.core import management
from django.test import TestCase, Client
from django.test import override_settings

from blanc_pages.models.pages import Page, PageVersion


@override_settings(ROOT_URLCONF='blanc_pages.tests.urls')
@override_settings(PASSWORD_HASHERS=('django.contrib.auth.hashers.MD5PasswordHasher',))
class TestListeners(TestCase):
    # fixtures = ['page_version.json']

    def setUp(self):

        # Page
        self.page = Page.objects.create(url='/test/', title='Test page')

        User = get_user_model()
        # Superuser
        self.superuser = User.objects.create_superuser('test', 'test@test.com', 'test')
        self.superuser_client = Client()
        self.superuser_client.login(username='test', password='test')

        # Page version.
        self.page_version = PageVersion.objects.create(
            page=self.page, template_name='blanc_pages/sample.html', owner=self.superuser
        )

    # def test_listener_with_fixtures(self):

    #     management.call_command('loaddata', 'page_version.json', verbosity=0)


