# -*- coding: utf-8 -*-

import blanc_pages


class SampleLayout(blanc_pages.BlancPageLayout):
    template_name = 'blanc_pages/sample.html'
    title = 'Sample'
    columns = {
        'Main Content': {
            'width': 480,
        },
        'Side': {
            'width': 320,
        },
    }


class Sample2Layout(blanc_pages.BlancPageLayout):
    template_name = 'blanc_pages/sample2.html'
    title = 'Sample'
    columns = {
        'Content': {
            'width': 480,
        },
        'Side': {
            'width': 320,
        },
        'RSide': {
            'width': 320,
        },

    }


blanc_pages.register_template(SampleLayout)
blanc_pages.register_template(Sample2Layout)

