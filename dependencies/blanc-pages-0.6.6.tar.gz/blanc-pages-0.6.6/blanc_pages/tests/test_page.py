# -*- coding: utf-8 -*-

import os

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType
from django.core.urlresolvers import reverse
from django.test import TestCase, Client, override_settings, modify_settings

from blanc_pages.exceptions import BlancPageColumnException
from blanc_pages.models.blocks import HTML
from blanc_pages.models.pages import Page, PageVersion, ContentBlock


@modify_settings(
    INSTALLED_APPS={
        'append': 'blanc_pages.tests.sample',
    },
)
@override_settings(
    PASSWORD_HASHERS=('django.contrib.auth.hashers.MD5PasswordHasher',),
    TEMPLATE_DIRS=(os.path.join(os.path.dirname(__file__), 'templates'),),
    ROOT_URLCONF='blanc_pages.tests.urls',
)
class TestAdmin(TestCase):

    def setUp(self):
        User = get_user_model()
        # Page
        self.page = Page.objects.create(url='/test/', title='Test page')

        # Permissions
        self.edit_permissions = Permission.objects.get_by_natural_key('edit_page', 'pages', 'page')

        # Editor with editing permissions
        self.editor = User.objects.create_user('editor', 'editor@test.com', 'editor')
        self.editor.is_staff = True
        self.editor.user_permissions.add(self.edit_permissions)
        self.editor.save()
        self.editor_client = Client()
        self.editor_client.login(username='editor', password='editor')

        # Page version.
        self.page_version = PageVersion.objects.create(
            page=self.page, template_name='blanc_pages/sample.html', owner=self.editor
        )

        self.html1_block = HTML.objects.create(content='<p>HTML Block</p>')
        self.html1_content_block = ContentBlock.objects.create(
            page_version=self.page_version,
            column='Main',
            position=1,
            content_type=ContentType.objects.get_for_model(self.html1_block),
            object_id=self.html1_block.pk
        )
        self.html1_block.content_block = self.html1_content_block
        self.html1_block.save()

        # Information about model
        self.info = self.page._meta.app_label, self.page._meta.model_name

        self.html1_block_delete_url = reverse(
            'admin:%s_%s_block_delete' % self.info, args=(self.html1_content_block.id,)
        )

    def test_column_is_not_defined(self):
        """ Test if column is defined. """
        with self.assertRaises(BlancPageColumnException):
            self.editor_client.post(self.html1_block_delete_url, {
                'block_type': 'pages.HTML',
                'column': 'Side',
            })

