# -*- coding: utf-8 -*-

import os

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.test import TestCase, Client
from django.test import override_settings, modify_settings

from blanc_pages.exceptions import BlancPageRedirectException
from blanc_pages.models.pages import Page, PageVersion
from blanc_pages.page import BlancPage


class MockRequest(object):
    pass


class MockSuperUser(object):
    def has_perm(self, perm):
        return True

request = MockRequest()
request.user = MockSuperUser()


@modify_settings(
    INSTALLED_APPS={
        'append': 'blanc_pages.tests.sample',
    },
)
@override_settings(ROOT_URLCONF='blanc_pages.tests.urls')
@override_settings(
    PASSWORD_HASHERS=('django.contrib.auth.hashers.MD5PasswordHasher',),
    TEMPLATE_DIRS=(os.path.join(os.path.dirname(__file__), 'templates'),),
    ROOT_URLCONF='blanc_pages.tests.urls',
)
class TestExceptionsBase(TestCase):
    def setUp(self):
        User = get_user_model()

        # Page
        self.page = Page.objects.create(url='/test/', title='Test page')

        # Permissions
        self.edit_permissions = Permission.objects.get_by_natural_key('edit_page', 'pages', 'page')
        # Editor with editing permissions
        self.editor = User.objects.create_user('editor', 'editor@test.com', 'editor')
        self.editor.is_staff = True
        self.editor.user_permissions.add(self.edit_permissions)
        self.editor.save()
        self.editor_client = Client()
        self.editor_client.login(username='editor', password='editor')

        # Page version.
        self.page_version = PageVersion.objects.create(
            page=self.page, template_name='blanc_pages/sample.html', owner=self.editor
        )
        self.blanc_page = BlancPage(self.page_version)


class TestBlancPageColumnException(TestExceptionsBase):
    def setUp(self):
        super(TestBlancPageColumnException, self).setUp()

    def test_page_redirect_exception(self):
        url = '/'
        exception = BlancPageRedirectException(url)
        self.assertEqual(exception.__str__(), 'Redirect to %s required' % (url,))

