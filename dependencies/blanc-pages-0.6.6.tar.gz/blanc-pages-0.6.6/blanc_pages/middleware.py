from blanc_pages.views import blancpage
from django.http import Http404


class BlancpageFallbackMiddleware(object):
    def process_response(self, request, response):
        if response.status_code != 404:
            return response  # No need to check for a page for non-404 responses.

        try:
            return blancpage(request, request.path_info)
        except Http404:
            # Return the original response if a 404 occurs
            return response
