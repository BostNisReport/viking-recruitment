# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import blanc_pages.models.pages
import django.db.models.deletion
from django.conf import settings
import mptt.fields


class Migration(migrations.Migration):

    dependencies = [
        ('contenttypes', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Page',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('url', models.CharField(validators=[blanc_pages.models.pages.validate_page_url], max_length=100, verbose_name='URL', unique=True)),
                ('title', models.CharField(max_length=100)),
                ('show_in_navigation', models.BooleanField(db_index=True, default=True)),
                ('published', models.BooleanField(db_index=True, default=True, verbose_name='Active')),
                ('note_count', models.PositiveIntegerField(default=0, editable=False)),
                ('unpublished_count', models.PositiveIntegerField(default=0, editable=False)),
                ('lft', models.PositiveIntegerField(db_index=True, editable=False)),
                ('rght', models.PositiveIntegerField(db_index=True, editable=False)),
                ('tree_id', models.PositiveIntegerField(db_index=True, editable=False)),
                ('level', models.PositiveIntegerField(db_index=True, editable=False)),
            ],
            options={
                'abstract': False,
                'db_table': 'blanc_pages_page',
                'ordering': ('url',),
                'permissions': (('edit_page', 'Can edit page'), ('publish_page', 'Can publish page')),
                'verbose_name': 'page',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='ContentBlock',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('column', models.CharField(db_index=True, max_length=100)),
                ('position', models.IntegerField(db_index=True, null=True)),
                ('object_id', models.PositiveIntegerField()),
                ('content_type', models.ForeignKey(to='contenttypes.ContentType')),
            ],
            options={
                'ordering': ('position',),
                'db_table': 'blanc_pages_contentblock',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='HTML',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('content', models.TextField()),
                ('content_block', models.ForeignKey(null=True, editable=False, to='pages.ContentBlock')),
            ],
            options={
                'db_table': 'blanc_pages_html',
                'verbose_name': 'HTML',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Note',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('created', models.DateTimeField(db_index=True, auto_now_add=True)),
                ('message', models.TextField()),
                ('archived', models.BooleanField(db_index=True, default=False)),
                ('page', models.ForeignKey(to='pages.Page')),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'ordering': ('-created',),
                'db_table': 'blanc_pages_note',
                'permissions': (('archive_note', 'Can archive note'),),
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='PageVersion',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('version_number', models.PositiveIntegerField(db_index=True, null=True)),
                ('template_name', models.CharField(max_length=70)),
                ('created', models.DateTimeField(db_index=True, auto_now_add=True)),
                ('modified', models.DateTimeField(db_index=True, auto_now=True)),
                ('owner', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to=settings.AUTH_USER_MODEL)),
                ('page', models.ForeignKey(to='pages.Page')),
            ],
            options={
                'ordering': ('-version_number',),
                'db_table': 'blanc_pages_pageversion',
            },
            bases=(models.Model,),
        ),
        migrations.AlterUniqueTogether(
            name='pageversion',
            unique_together=set([('page', 'version_number')]),
        ),
        migrations.AddField(
            model_name='contentblock',
            name='page_version',
            field=models.ForeignKey(to='pages.PageVersion'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='page',
            name='current_version',
            field=models.ForeignKey(to='pages.PageVersion', related_name='+', null=True, editable=False, blank=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='page',
            name='parent',
            field=mptt.fields.TreeForeignKey(related_name='children', null=True, to='pages.Page', blank=True),
            preserve_default=True,
        ),
    ]
