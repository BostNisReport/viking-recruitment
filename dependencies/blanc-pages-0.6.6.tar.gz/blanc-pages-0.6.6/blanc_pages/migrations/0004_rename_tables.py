# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('pages', '0003_remove_notes'),
    ]

    operations = [
        migrations.AlterModelTable(
            name='contentblock',
            table=None,
        ),
        migrations.AlterModelTable(
            name='html',
            table=None,
        ),
        migrations.AlterModelTable(
            name='page',
            table=None,
        ),
        migrations.AlterModelTable(
            name='pageversion',
            table=None,
        ),
    ]
