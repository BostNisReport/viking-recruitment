# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('pages', '0002_page_login_required'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='note',
            name='page',
        ),
        migrations.RemoveField(
            model_name='note',
            name='user',
        ),
        migrations.DeleteModel(
            name='Note',
        ),
        migrations.RemoveField(
            model_name='page',
            name='note_count',
        ),
    ]
