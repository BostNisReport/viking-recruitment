# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations


def fix_contentblocks(apps, schema_editor):
    ContentBlock = apps.get_model('pages', 'ContentBlock')

    # Go through all existing content blocks and renumber them to avoid any duplicates - the next
    # migration adds a unique which prevents the problem
    prev = None

    for block in ContentBlock.objects.order_by('page_version_id', 'column', 'position', 'id'):
        if prev is None:
            # First block
            position = 1
        elif (prev.page_version_id, prev.column) != (block.page_version_id, block.column):
            # First block of another page version or column - reset position
            position = 1
        else:
            # Current column, next block
            position += 1

        block.position = position
        block.save()

        prev = block


def no_reverse(apps, schema_editor):
    pass


class Migration(migrations.Migration):

    dependencies = [
        ('pages', '0004_rename_tables'),
    ]

    operations = [
        migrations.RunPython(fix_contentblocks, no_reverse),
    ]
