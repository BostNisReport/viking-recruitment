# -*- coding: utf-8 -*-

import json

from functools import update_wrapper

from django.apps import apps
from django.conf import settings
from django.contrib import admin
from django.contrib.admin.models import LogEntry, CHANGE
from django.contrib.admin.options import csrf_protect_m
from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import PermissionDenied
from django.core.urlresolvers import reverse
from django.db import models, transaction
from django.db.models import F, Q
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404
from django.template.defaultfilters import slugify
from django.template.response import TemplateResponse
from django.utils.decorators import method_decorator
from django.utils.encoding import force_text
from django.utils.html import escape
from django.views.decorators.http import require_POST

from django_mptt_admin.admin import DjangoMpttAdmin

from .import get_template
from .forms import get_newpagetemplateform, get_addblock_form, MoveBlockForm, get_movecolumn_form
from .models import Page, PageVersion, ContentBlock
from .page import BlancPage
from .signals import page_version_saved, page_version_published, page_version_unpublished
from .utils import JSONEncoderForHTML, duplicate
from .views import render_page


require_post_m = method_decorator(require_POST)


def page_admin_fields():
    fields = ['url', 'title', 'parent', 'login_required', 'show_in_navigation', 'published']

    # Don't show login_required unless needed
    if not getattr(settings, 'BLANC_PAGES_SHOW_LOGIN_REQUIRED', False):
        fields.remove('login_required')

    return fields


class PageAdmin(DjangoMpttAdmin):
    list_display = ('admin_url', 'title', 'admin_unpublished_count')
    fields = page_admin_fields()

    def admin_url(self, obj):
        info = self.model._meta.app_label, self.model._meta.model_name
        redirect_url = reverse('admin:%s_%s_redirect' % info, kwargs={'page_pk': obj.pk})
        return u'<a href="%s">%s</a>' % (redirect_url, escape(obj.url))
    admin_url.short_description = 'URL'
    admin_url.allow_tags = True

    def admin_unpublished_count(self, obj):
        return obj.unpublished_count or '&nbsp;'
    admin_unpublished_count.short_description = 'Unpublished'
    admin_unpublished_count.allow_tags = True

    def get_urls(self):
        from django.conf.urls import url

        def wrap(view):
            def wrapper(*args, **kwargs):
                return self.admin_site.admin_view(view)(*args, **kwargs)
            return update_wrapper(wrapper, view)

        info = self.model._meta.app_label, self.model._meta.model_name

        urlpatterns = [
            # Start a page with a brand new template
            url(r'^(?P<page_pk>\d+)/template/$',
                wrap(self.page_template_view),
                name='%s_%s_template' % info),

            # Redirect a user to view the latest appropriate page
            url(r'^(?P<page_pk>\d+)/redirect/$',
                wrap(self.page_redirect_view),
                name='%s_%s_redirect' % info),

            # View and edit
            url(r'^editor/view/(?P<pk>\d+)/$',
                wrap(self.page_version_view),
                name='%s_%s_version' % info),
            url(r'^editor/edit/(?P<pk>\d+)/$',
                wrap(self.page_edit_view),
                name='%s_%s_edit' % info),

            # Change template
            url(r'^editor/changetemplate/(?P<pk>\d+)/$',
                wrap(self.page_changetemplate_view),
                name='%s_%s_changetemplate' % info),

            # Save, publish, discard
            url(r'^edit/page/(?P<pk>\d+)/save/$',
                wrap(self.page_save_view),
                name='%s_%s_save' % info),
            url(r'^edit/page/(?P<pk>\d+)/publish/$',
                wrap(self.page_publish_view),
                name='%s_%s_publish' % info),
            url(r'^edit/page/(?P<pk>\d+)/unpublish/$',
                wrap(self.page_unpublish_view),
                name='%s_%s_unpublish' % info),
            url(r'^edit/page/(?P<pk>\d+)/discard/$',
                wrap(self.page_discard_view),
                name='%s_%s_discard' % info),

            # Block add
            url(r'^edit/page/(?P<pk>\d+)/block/add/$',
                wrap(self.page_block_add_view),
                name='%s_%s_block_add' % info),

            # Block editing/updating/moving
            url(r'^edit/block/del/(?P<pk>\d+)/$',
                wrap(self.page_block_delete_view),
                name='%s_%s_block_delete' % info),
            url(r'^edit/block/move/(?P<pk>\d+)/$',
                wrap(self.page_block_move_view),
                name='%s_%s_block_move' % info),
            url(r'^edit/block/column/(?P<pk>\d+)/$',
                wrap(self.page_block_column_view),
                name='%s_%s_block_column' % info),

        ] + super(PageAdmin, self).get_urls()
        return urlpatterns

    def has_edit_permission(self, request, obj=None):
        return request.user.has_perm(self.opts.app_label + '.' + 'edit_page')

    def has_publish_permission(self, request, obj=None):
        return request.user.has_perm(self.opts.app_label + '.' + 'publish_page')

    def response_add(self, request, obj, *args, **kwargs):
        if '_saveandedit' in request.POST:
            return self.page_redirect(request, obj)
        else:
            return super(PageAdmin, self).response_add(request, obj, *args, **kwargs)

    def response_change(self, request, obj, *args, **kwargs):
        if '_saveandedit' in request.POST:
            return self.page_redirect(request, obj)
        else:
            return super(PageAdmin, self).response_change(request, obj, *args, **kwargs)

    @csrf_protect_m
    @transaction.atomic
    def page_template_view(self, request, page_pk):
        page = get_object_or_404(self.model, pk=page_pk)

        if not self.has_edit_permission(request, page):
            raise PermissionDenied

        NewPageTemplateForm = get_newpagetemplateform()
        form = NewPageTemplateForm(request.POST or None)

        if form.is_valid():
            page_version = form.save(commit=False)
            page_version.page = page
            page_version.owner = request.user
            page_version.save()

            info = self.model._meta.app_label, self.model._meta.model_name
            return HttpResponseRedirect(reverse('admin:%s_%s_version' % info, kwargs={
                'pk': page_version.pk,
            }))

        return TemplateResponse(request, 'admin/blanc_pages/new_template.html', {
            'form': form,
        })

    def page_redirect(self, request, page):
        info = self.model._meta.app_label, self.model._meta.model_name

        if not self.has_edit_permission(request, page):
            raise PermissionDenied

        # Redirect a user to the published page if it has one
        if page.current_version:
            return HttpResponseRedirect(page.url)

        # Otherwise we'll go for the latest version a user has access to
        try:
            page_version = page.pageversion_set.exclude(
                ~Q(owner=request.user), version_number__isnull=True)[0]
            return HttpResponseRedirect(reverse('admin:%s_%s_version' % info, kwargs={
                'pk': page_version.pk,
            }))
        except IndexError:
            pass

        # Last resort is getting the user to create a new page with a new template
        return HttpResponseRedirect(reverse('admin:%s_%s_template' % info, kwargs={
            'page_pk': page.pk,
        }))

    def page_redirect_view(self, request, page_pk):
        page = get_object_or_404(self.model, pk=page_pk)
        return self.page_redirect(request, page)

    def page_version_view(self, request, pk):
        page_version = get_object_or_404(PageVersion.objects.select_related(), pk=pk)

        if not self.has_edit_permission(request, page_version.page):
            raise PermissionDenied

        # Deny other users from viewing an unsaved version
        if not page_version.version_number and page_version.owner != request.user:
            raise PermissionDenied

        return render_page(request, page_version.page, page_version)

    @csrf_protect_m
    @transaction.atomic
    def page_edit_view(self, request, pk):
        info = self.model._meta.app_label, self.model._meta.model_name
        page_version = get_object_or_404(PageVersion.objects.select_related(), pk=pk)

        if not self.has_edit_permission(request, page_version.page):
            raise PermissionDenied

        # Deny other users from viewing an unsaved version
        if not page_version.version_number and page_version.owner != request.user:
            raise PermissionDenied

        # POST request to initiate
        if request.method == 'POST':
            # No need to copy a version if they're still editing it
            if not page_version.version_number:
                return HttpResponseRedirect(reverse('admin:%s_%s_edit' % info, kwargs={'pk': pk}))

            # Create a copy of this version for the user
            new_page_version = PageVersion.objects.create(
                page=page_version.page,
                template_name=page_version.template_name,
                owner=request.user)

            for i in page_version.contentblock_set.all():
                # Copy the block
                new_block = duplicate(i.content_object)
                new_block.save()

                # Copy the content block
                content_block = i
                content_block.id = None
                content_block.content_object = new_block
                content_block.page_version = new_page_version
                content_block.save()

                # Point the block back to the ContentBlock
                new_block.content_block = content_block
                new_block.save()

            return HttpResponseRedirect(reverse('admin:%s_%s_edit' % info, kwargs={
                'pk': new_page_version.pk,
            }))

        # Redirect to view if the version is already saved
        if page_version.version_number:
            return HttpResponseRedirect(reverse('admin:%s_%s_version' % info, kwargs={'pk': pk}))

        return render_page(request, page_version.page, page_version, edit=True)

    @csrf_protect_m
    @transaction.atomic
    def page_changetemplate_view(self, request, pk):
        page_version = get_object_or_404(PageVersion, pk=pk)

        if not self.has_edit_permission(request, page_version.page):
            raise PermissionDenied

        # Can't change a saved page version
        if page_version.version_number:
            raise PermissionDenied

        old_template = get_template(page_version.template_name)
        NewPageTemplateForm = get_newpagetemplateform()
        form = NewPageTemplateForm(request.POST, instance=page_version)

        # Deny other users from viewing an unsaved version
        if not page_version.version_number and page_version.owner != request.user:
            raise PermissionDenied

        if form.is_valid():
            page_version = form.save()
            new_template = get_template(page_version.template_name)

            # If any columns don't exist in the new template, default them to the first column
            for i in old_template.columns:
                if i not in new_template.columns:
                    # Find the first column to put this content in - sadly this is currently the
                    # first column alphabetically for consistency. In future this will be the first
                    # column defined (the most important one).
                    new_column = sorted(new_template.columns.keys())[0]

                    # Find the last block in the new first column
                    last_block = ContentBlock.objects.filter(
                        page_version=page_version, column=new_column).last()

                    if last_block is not None:
                        next_position = last_block.position + 1
                    else:
                        next_position = 1

                    # Append to the first column
                    for content in ContentBlock.objects.filter(page_version=page_version, column=i):
                        content.column = new_column
                        content.position = next_position
                        content.save()
                        next_position += 1

        info = self.model._meta.app_label, self.model._meta.model_name
        return HttpResponseRedirect(reverse('admin:%s_%s_edit' % info, kwargs={'pk': pk}))

    @csrf_protect_m
    @require_post_m
    @transaction.atomic
    def page_save_view(self, request, pk):
        page_version = get_object_or_404(PageVersion, pk=pk)

        if not self.has_edit_permission(request, page_version.page):
            raise PermissionDenied

        # Deny other users from saving a users version
        if page_version.owner != request.user:
            raise PermissionDenied

        # No need for errors, save anything and only update unsaved versions
        if not page_version.version_number:
            page_version.generate_version()
            page_version.save()

            page_version_saved.send(
                sender=page_version.page.__class__,
                page=page_version.page,
                page_version=page_version,
                user=request.user)

        info = self.model._meta.app_label, self.model._meta.model_name
        return HttpResponseRedirect(reverse('admin:%s_%s_version' % info, kwargs={'pk': pk}))

    @csrf_protect_m
    @require_post_m
    @transaction.atomic
    def page_publish_view(self, request, pk):
        page_version = get_object_or_404(PageVersion, pk=pk)
        page = page_version.page

        if not self.has_publish_permission(request, page_version.page):
            raise PermissionDenied

        # Deny other users from publishing an unsaved version
        if not page_version.version_number and page_version.owner != request.user:
            raise PermissionDenied

        # Repeated publish - ignore
        if page.current_version == page_version:
            return HttpResponseRedirect(page.url)

        # Save the page if it isn't already
        if not page_version.version_number:
            page_version.generate_version()
            page_version.save()

            page_version_saved.send(
                sender=page_version.page.__class__,
                page=page_version.page,
                page_version=page_version,
                publish=True,
                user=request.user)

        # Publish!
        previous_version = page.current_version
        page.current_version = page_version
        page.save()

        page_version_published.send(
            sender=page_version.page.__class__,
            page=page_version.page,
            page_version=page_version,
            previous_version=previous_version,
            user=request.user)

        message = 'Published version %d' % (page_version.version_number,)
        LogEntry.objects.log_action(
            user_id=request.user.pk,
            content_type_id=ContentType.objects.get_for_model(page).pk,
            object_id=page.pk,
            object_repr=force_text(page),
            action_flag=CHANGE,
            change_message=message
        )

        return HttpResponseRedirect(page.url)

    @csrf_protect_m
    @require_post_m
    @transaction.atomic
    def page_unpublish_view(self, request, pk):
        page_version = get_object_or_404(PageVersion, pk=pk)
        page = page_version.page

        if not self.has_publish_permission(request, page_version.page):
            raise PermissionDenied

        # Not the current version? Just ignore the action and view the page again
        if page.current_version == page_version:
            page.current_version = None
            message = 'Unpublished page'

            page_version_unpublished.send(
                sender=page_version.page.__class__,
                page=page_version.page,
                page_version=page_version,
                user=request.user)
            page.save()

            LogEntry.objects.log_action(
                user_id=request.user.pk,
                content_type_id=ContentType.objects.get_for_model(page).pk,
                object_id=page.pk,
                object_repr=force_text(page),
                action_flag=CHANGE,
                change_message=message
            )

        info = self.model._meta.app_label, self.model._meta.model_name
        return HttpResponseRedirect(reverse('admin:%s_%s_version' % info, kwargs={
            'pk': page_version.pk,
        }))

    @csrf_protect_m
    @transaction.atomic
    def page_discard_view(self, request, pk):
        page_version = get_object_or_404(PageVersion, pk=pk)
        page = page_version.page

        if not self.has_edit_permission(request, page_version.page):
            raise PermissionDenied

        # Page version must not be saved, and must belong to this user
        if page_version.version_number or page_version.owner != request.user:
            raise PermissionDenied

        # POST request to initiate
        if request.method == 'POST':
            # Remove all blocks
            for i in page_version.contentblock_set.all():
                i.delete()

            page_version.delete()

            return TemplateResponse(request, 'admin/blanc_pages/page_discarded.html', {
                'page': page,
                'opts': self.model._meta,
            }, current_app=self.admin_site.name)

        return TemplateResponse(request, 'admin/blanc_pages/page_discard.html', {
        }, current_app=self.admin_site.name)

    @csrf_protect_m
    @transaction.atomic
    def page_block_add_view(self, request, pk):
        page_version = get_object_or_404(PageVersion, pk=pk)

        if not self.has_edit_permission(request, page_version.page):
            raise PermissionDenied

        # Page version must not be saved, and must belong to this user
        if page_version.version_number or page_version.owner != request.user:
            raise PermissionDenied

        AddBlockForm = get_addblock_form(page_version)
        form = AddBlockForm(request.POST, instance=ContentBlock(page_version=page_version))

        response = HttpResponse(content_type='application/json')
        response_dict = {}

        if form.is_valid():
            # Figure out the block type we need
            new_obj_class = form.cleaned_data['block_type']
            app_name, model_name = new_obj_class.split('.', 1)
            new_obj_class = apps.get_model(app_name, model_name)

            # Create the block
            block = new_obj_class.objects.create()

            # Create a ContentBlock pointing to it
            content_block = form.save(commit=False)
            content_block.content_object = block

            if form.cleaned_data['top']:
                # User wants block at the top of the column, so set the position or it'll end up
                # being autosaved to the end of the column
                first_block = ContentBlock.objects.filter(
                    page_version=page_version, column=content_block.column).first()

                if first_block is not None:
                    content_block.position = first_block.position - 1

            content_block.save()

            # Point the block back to the ContentBlock
            block.content_block = content_block
            block.save()

            # Updated the modified timestamp
            page_version.save()

            # Render the updated column
            response_dict['column'] = slugify(content_block.column)
            blanc_page = BlancPage(content_block.page_version, edit_mode=True, request=request)
            response_dict['content'] = blanc_page.render_column(content_block.column, rerender=True)

        json.dump(response_dict, response)
        return response

    @csrf_protect_m
    @transaction.atomic
    def page_block_delete_view(self, request, pk):
        content_block = get_object_or_404(ContentBlock, pk=pk)
        block = content_block.content_object
        page_version = content_block.page_version

        if not self.has_edit_permission(request, page_version.page):
            raise PermissionDenied

        # Page version must not be saved, and must belong to this user
        if page_version.version_number or page_version.owner != request.user:
            raise PermissionDenied

        if request.POST:
            # Save variables for use after deletion
            page_version = content_block.page_version
            column = content_block.column

            # Delete the block
            content_block.delete()
            block.delete()

            # Render the updated column as a JSON object
            blanc_page = BlancPage(page_version, edit_mode=True, request=request)
            rendered_json = JSONEncoderForHTML().encode({
                'content': blanc_page.render_column(column, rerender=True),
            })

            return TemplateResponse(request, 'admin/blanc_pages/update_column.html', {
                'column': slugify(column),
                'rendered_json': rendered_json,
            }, current_app=self.admin_site.name)

        return TemplateResponse(request, 'admin/blanc_pages/block_delete.html', {
            'content_block': block,
        }, current_app=self.admin_site.name)

    @csrf_protect_m
    @transaction.atomic
    def page_block_move_view(self, request, pk):
        content_block = get_object_or_404(ContentBlock, pk=pk)
        page_version = content_block.page_version

        if not self.has_edit_permission(request, page_version.page):
            raise PermissionDenied

        # Page version must not be saved, and must belong to this user
        if page_version.version_number or page_version.owner != request.user:
            raise PermissionDenied

        form = MoveBlockForm(request.POST)
        response = HttpResponse(content_type='application/json')
        response_dict = {}

        if form.is_valid():

            move = form.cleaned_data['move']

            if move == MoveBlockForm.MOVE_UP or move == MoveBlockForm.MOVE_DOWN:
                # Move up/down involve swapping block positions

                try:
                    if move == MoveBlockForm.MOVE_UP:
                        other_block = ContentBlock.objects.filter(
                            page_version=content_block.page_version,
                            column=content_block.column,
                            position__lt=content_block.position).order_by('-position')[0]
                    else:
                        other_block = ContentBlock.objects.filter(
                            page_version=content_block.page_version,
                            column=content_block.column,
                            position__gt=content_block.position)[0]

                    old_position = content_block.position
                    new_position = other_block.position

                    # Temporarily unset other_block's position
                    other_block.position = None
                    other_block.save()

                    # Now set the appropriate positions
                    content_block.position = new_position
                    content_block.save()

                    other_block.position = old_position
                    other_block.save()

                except IndexError:
                    # User tried to move a block too far
                    pass

            else:
                if move == MoveBlockForm.MOVE_TOP:
                    # Move to top requires setting the position to one less than the first
                    other_block = ContentBlock.objects.filter(
                        page_version=content_block.page_version, column=content_block.column)[0]

                    # This could be the first block
                    if content_block != other_block:
                        content_block.position = other_block.position - 1
                        content_block.save()
                else:
                    # Move bottom requires setting the position to one greater than the last
                    other_block = ContentBlock.objects.filter(
                        page_version=content_block.page_version,
                        column=content_block.column).order_by('-position')[0]

                    # This could be the last block
                    if content_block != other_block:
                        content_block.position = other_block.position + 1
                        content_block.save()

            response_dict['column'] = slugify(content_block.column)
            blanc_page = BlancPage(content_block.page_version, edit_mode=True, request=request)
            response_dict['content'] = blanc_page.render_column(content_block.column, rerender=True)

        json.dump(response_dict, response)
        return response

    @csrf_protect_m
    @transaction.atomic
    def page_block_column_view(self, request, pk):
        content_block = get_object_or_404(ContentBlock, pk=pk)
        page_version = content_block.page_version

        if not self.has_edit_permission(request, page_version.page):
            raise PermissionDenied

        # Page version must not be saved, and must belong to this user
        if page_version.version_number or page_version.owner != request.user:
            raise PermissionDenied

        # Need to build a form which only has viable column moves
        template_obj = get_template(content_block.page_version.template_name)
        column_choices = list(template_obj.columns)
        column_choices.remove(content_block.column)

        MoveColumnForm = get_movecolumn_form(column_choices)
        form = MoveColumnForm(request.POST)

        response = HttpResponse(content_type='application/json')
        response_dict = {}

        if form.is_valid():
            move = form.cleaned_data['move']
            source_column = content_block.column

            content_block.column = move

            # Find the last block of the column we're moving to
            if ContentBlock.objects.filter(
                    page_version=content_block.page_version, column=move
            ).order_by('-position').exists():
                last_block = ContentBlock.objects.filter(
                    page_version=content_block.page_version, column=move
                ).order_by('-position')[0]
                content_block.position = last_block.position + 1

            content_block.save()

            # Setup the page that can render both updated columns
            blanc_page = BlancPage(page_version, edit_mode=True, request=request)

            # Old column needs rendering again
            response_dict['source_column'] = slugify(source_column)
            response_dict['source_content'] = blanc_page.render_column(
                source_column, rerender=True
            )

            # Now render the destination column
            response_dict['dest_column'] = slugify(content_block.column)
            response_dict['dest_content'] = blanc_page.render_column(
                content_block.column, rerender=True)

        json.dump(response_dict, response)
        return response


admin.site.register(Page, PageAdmin)
