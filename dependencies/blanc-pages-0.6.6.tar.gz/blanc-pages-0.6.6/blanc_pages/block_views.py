from django.template.loader import render_to_string


def baseblock(block, request, rerender, content_block, block_classes):
    css_classes = ' '.join(block_classes)

    return render_to_string((
        'blanc_pages/blocks/%s.html' % (block._meta.model_name,),
        'blanc_pages/blocks/baseblock.html',
    ), {
        'content_block': content_block,
        'css_classes': css_classes,
        'object': block,
    })
