# -*- coding: utf-8 -*-

from django import template
from django.template.loader import get_template

register = template.Library()


@register.simple_tag(takes_context=True)
def blancpage_head(context):
    """
    Template tag which renders the blanc page CSS and JavaScript. Any resources
    which need to be loaded should be added here. This is only shown to users
    with permission to edit the page.
    """
    blanc_page = context.get('blanc_page')

    if blanc_page and blanc_page.show_controls:
        template = get_template('blanc_pages/include/head.html')
        return template.render(context)

    return ''


@register.simple_tag(takes_context=True)
def blancpage_startbody(context):
    """
    Template tag which renders the blanc page overlay and sidebar. This is only
    shown to users with permission to edit the page.
    """
    blanc_page = context.get('blanc_page')

    if blanc_page and blanc_page.show_controls:
        template = get_template('blanc_pages/include/startbody.html')
        return template.render(context)

    return ''


@register.simple_tag
def blancpage_render_column(blanc_page, column_name):
    """
    Renders a column template.

    Example::
        {% blancpage_render_column blanc_page "Column Name" %}
    """
    return blanc_page.render_column(column_name)
