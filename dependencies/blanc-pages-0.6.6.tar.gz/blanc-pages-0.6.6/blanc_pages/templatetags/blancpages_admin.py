from django import template
from django.contrib.admin.templatetags.admin_modify import submit_row

register = template.Library()


@register.inclusion_tag('admin/blanc_pages/page/submit_line.html', takes_context=True)
def blanc_pages_submit_row(context):
    return submit_row(context)
