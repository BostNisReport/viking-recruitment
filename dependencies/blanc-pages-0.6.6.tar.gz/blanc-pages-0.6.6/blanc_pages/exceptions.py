# -*- coding: utf-8 -*-


class BlancPageColumnException(Exception):
    """Invalid column was passed to layout columns."""
    pass


class BlancPageRedirectException(Exception):
    def __init__(self, url):
        self.url = url

    def __str__(self):
        return 'Redirect to %s required' % (self.url,)

