# -*- coding: utf-8 -*-

from django.db import models
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey
from django.conf import settings
from django.core.exceptions import ValidationError
from django.utils.encoding import python_2_unicode_compatible
from mptt.models import MPTTModel, TreeForeignKey
from mptt.managers import TreeManager


USER_MODEL = getattr(settings, 'AUTH_USER_MODEL', 'auth.User')


class PageManager(TreeManager):
    def published(self):
        return self.get_query_set().filter(published=True)


def validate_page_url(value):
    if not value.startswith('/'):
        raise ValidationError('URL must start with a /')

    if not value.endswith('/'):
        raise ValidationError('URL must end with a /')

    if value.startswith('//'):
        raise ValidationError('Protocol relative URLs are not allowed')


@python_2_unicode_compatible
class Page(MPTTModel):
    url = models.CharField('URL', max_length=100, unique=True, validators=[validate_page_url])
    title = models.CharField(max_length=100)
    parent = TreeForeignKey('self', null=True, blank=True, related_name='children')
    login_required = models.BooleanField(default=False)
    show_in_navigation = models.BooleanField(default=True, db_index=True)
    published = models.BooleanField('Active', default=True, db_index=True)
    current_version = models.ForeignKey('PageVersion', related_name='+', blank=True, null=True, editable=False)
    unpublished_count = models.PositiveIntegerField(default=0, editable=False)

    objects = PageManager()

    def __str__(self):
        return '%s -- %s' % (self.title, self.url)

    class Meta:
        verbose_name = 'page'
        ordering = ('url',)
        permissions = (
            ('edit_page', 'Can edit page'),
            ('publish_page', 'Can publish page'),
            ('view_protected_page', 'Can view protected page'),
        )

    def get_absolute_url(self):
        return self.url

    def save(self, *args, **kwargs):
        # Find the number of unpublished pages
        unpublished_pages = self.pageversion_set.exclude(version_number__isnull=True)

        if self.current_version:
            unpublished_pages = unpublished_pages.filter(version_number__gt=self.current_version.version_number)

        self.unpublished_count = unpublished_pages.count()

        super(Page, self).save(*args, **kwargs)


@python_2_unicode_compatible
class PageVersion(models.Model):
    page = models.ForeignKey('pages.Page')
    version_number = models.PositiveIntegerField(db_index=True, null=True)
    template_name = models.CharField(max_length=70)
    created = models.DateTimeField(auto_now_add=True, db_index=True)
    modified = models.DateTimeField(auto_now=True, db_index=True)
    owner = models.ForeignKey(USER_MODEL, on_delete=models.PROTECT)

    class Meta:
        ordering = ('-version_number',)
        unique_together = (
            ('page', 'version_number'),
        )

    def __str__(self):
        if self.version_number:
            return '%s (version %d)' % (str(self.page), self.version_number)
        else:
            return '%s (unpublished version %s)' % (str(self.page), self.created)

    def generate_version(self):
        # Create a version number if the page doesn't have one already
        if not self.version_number:
            try:
                prev_version = PageVersion.objects.filter(page=self.page).exclude(version_number__isnull=True)[0].version_number
            except IndexError:
                prev_version = 0

            self.version_number = prev_version + 1

        return self.version_number

    @property
    def is_published(self):
        if self.version_number and self.page.published and self.page.current_version == self:
            return True
        else:
            return False


class ContentBlock(models.Model):
    page_version = models.ForeignKey(PageVersion)
    column = models.CharField(max_length=100, db_index=True)
    position = models.IntegerField(null=True, db_index=True)
    content_type = models.ForeignKey(ContentType)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')

    class Meta:
        ordering = ('position',)
        unique_together = (
            ('page_version', 'column', 'position'),
        )

    def save(self, *args, **kwargs):
        # Set the position to the highest possible if there isn't one already
        if self.position is None:
            last_position = ContentBlock.objects.filter(
                page_version=self.page_version, column=self.column).aggregate(
                models.Max('position'))['position__max']

            # Just incase it's the first block in this column
            if last_position is None:
                self.position = 1
            else:
                self.position = last_position + 1

        super(ContentBlock, self).save(*args, **kwargs)
