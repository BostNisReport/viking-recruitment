from django.db import models
from blanc_pages.models.pages import ContentBlock


class BaseBlock(models.Model):
    content_block = models.ForeignKey(ContentBlock, null=True, editable=False)

    # Override if more complex view logic is needed
    render_function = 'blanc_pages.block_views.baseblock'

    class Meta:
        abstract = True


class HTML(BaseBlock):
    content = models.TextField()

    class Meta:
        verbose_name = 'HTML'
