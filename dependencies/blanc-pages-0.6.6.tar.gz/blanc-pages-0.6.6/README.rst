===========
Blanc Pages
===========

A powerful replacement for Django flatpages, with support for multiple columns
of content, versioning, tree structured site navigation, and more!
