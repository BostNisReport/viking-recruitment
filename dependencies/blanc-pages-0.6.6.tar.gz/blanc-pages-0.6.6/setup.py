#!/usr/bin/env python
from setuptools import find_packages, setup


setup(
    name='blanc-pages',
    version='0.6.6',
    description='Blanc Pages for Django',
    long_description=open('README.rst').read(),
    url='http://www.blanctools.com/',
    maintainer='Blanc Ltd',
    maintainer_email='studio@blanc.ltd.uk',
    platforms=['any'],
    packages=find_packages(),
    package_data={'blanc_pages': [
        'static/blanc_pages/css/*.css',
        'static/blanc_pages/css/*.less',
        'static/blanc_pages/fonts/handbookglyphs.*',
        'static/blanc_pages/img/*.png',
        'static/blanc_pages/js/*.js',
        'templates/admin/blanc_pages/*.html',
        'templates/admin/blanc_pages/page/*.html',
        'templates/blanc_pages/blocks/*.html',
        'templates/blanc_pages/include/*.html',
        'templates/blockadmin/*.html',
    ]},
    classifiers=[
        'Environment :: Web Environment',
        'Framework :: Django',
        'License :: Other/Proprietary License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
    ],
    license='Proprietary',
)
