==================
Blanc Basic Events
==================

A simple events calendar for Django.
