#!/usr/bin/env python
try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup


setup(
    name='django-redactorjs-staticfiles',
    version='9.2.6',
    description='RedactorJS Static Files',
    long_description=open('README.rst').read(),
    url='http://www.redactorjs.com/',
    maintainer='Alex Tomkins',
    maintainer_email='alex@hawkz.com',
    platforms=['any'],
    packages=[
        'redactorjs_staticfiles',
    ],
    package_data={'redactorjs_staticfiles': [
        'static/redactorjs/*.eot',
        'static/redactorjs/*.js',
        'static/redactorjs/*.css',
        'static/redactorjs/langs/*.js',
    ]},
    classifiers=[
        'Environment :: Web Environment',
        'Framework :: Django',
        'License :: Other/Proprietary License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
    ],
    license='Proprietary',
)
