======================
Blanc Pages Form Block
======================

Base form block.
