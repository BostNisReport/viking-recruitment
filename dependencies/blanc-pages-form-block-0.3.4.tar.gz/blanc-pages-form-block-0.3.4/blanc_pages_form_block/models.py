from blanc_pages.models.blocks import BaseBlock
from django.db import models
from mptt.fields import TreeForeignKey


class BaseFormBlock(BaseBlock):
    recipient = models.EmailField()
    success_page = TreeForeignKey('pages.Page', null=True, on_delete=models.SET_NULL)

    render_function = 'blanc_pages_form_block.views.form_view'

    class Meta:
        abstract = True


class BaseFormNoEmailBlock(BaseBlock):
    success_page = TreeForeignKey('pages.Page', null=True, on_delete=models.SET_NULL)

    render_function = 'blanc_pages_form_block.views.form_view'

    class Meta:
        abstract = True
