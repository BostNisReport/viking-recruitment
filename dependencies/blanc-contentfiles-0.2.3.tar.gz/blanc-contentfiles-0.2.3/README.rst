Blanc Content Files
===================

Package for Blanc Django media configuration. This is unlikely to be of any use
to anyone else - but it exists on PyPI and GitHub to make it easier for us to
maintain and install with pip.

Installation
------------

Using pip_:

.. _pip: https://pip.pypa.io/

.. code-block:: console

    $ pip install blanc-contentfiles
