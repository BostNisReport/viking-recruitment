from django.apps import AppConfig


class BlancBasicNewsConfig(AppConfig):
    name = 'blanc_basic_news'
    label = 'news'
