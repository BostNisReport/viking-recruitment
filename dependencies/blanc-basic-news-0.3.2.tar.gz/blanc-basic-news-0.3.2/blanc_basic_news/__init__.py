
default_app_config = 'blanc_basic_news.apps.BlancBasicNewsConfig'
