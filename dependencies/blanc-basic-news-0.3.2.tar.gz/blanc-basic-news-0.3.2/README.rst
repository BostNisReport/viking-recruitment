Blanc Basic News
================

A simple news/blog for Django.

Installation
------------

Using pip_:

.. _pip: https://pip.pypa.io/

.. code-block:: console

    $ pip install blanc-basic-news

Documentation
-------------

Package documentation is hosted on `Read the Docs`_, see
https://blanc-basic-news.readthedocs.org/

.. _Read the Docs: https://readthedocs.org/
