.. ref-rds2

====
RDS2
====

boto.rds2
---------

.. automodule:: boto.rds2
   :members:
   :undoc-members:

boto.rds2.exceptions
--------------------

.. automodule:: boto.rds2.exceptions
   :members:
   :undoc-members:

boto.rds2.layer1
----------------

.. automodule:: boto.rds2.layer1
   :members:
   :undoc-members:
