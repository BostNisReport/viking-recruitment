.. ref-machinelearning

================
Machine Learning
================

boto.machinelearning
--------------------

.. automodule:: boto.machinelearning
   :members:
   :undoc-members:

boto.machinelearning.layer1
---------------------------

.. automodule:: boto.machinelearning.layer1
   :members:
   :undoc-members:

boto.machinelearning.exceptions
-------------------------------

.. automodule:: boto.machinelearning.exceptions
   :members:
   :undoc-members:
