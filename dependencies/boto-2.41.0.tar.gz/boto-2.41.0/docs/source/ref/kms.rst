.. ref-kms

===
KMS
===

boto.kms
--------

.. automodule:: boto.kms
   :members:
   :undoc-members:

boto.kms.layer1
---------------

.. automodule:: boto.kms.layer1
   :members:
   :undoc-members:

boto.kms.exceptions
-----------------------

.. automodule:: boto.kms.exceptions
   :members:
   :undoc-members:
