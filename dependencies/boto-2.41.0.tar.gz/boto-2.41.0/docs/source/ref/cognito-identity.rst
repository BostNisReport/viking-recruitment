.. ref-cognito-identity

================
Cognito Identity
================

boto.cognito.identity
---------------------

.. automodule:: boto.cognito.identity
   :members:
   :undoc-members:

boto.cognito.identity.layer1
----------------------------

.. automodule:: boto.cognito.identity.layer1
   :members:
   :undoc-members:

boto.cognito.identity.exceptions
--------------------------------

.. automodule:: boto.cognito.identity.exceptions
   :members:
   :undoc-members:
