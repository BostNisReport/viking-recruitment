#!/usr/bin/env python
from setuptools import find_packages, setup


setup(
    name='blanc-pages-redactor-block',
    version='0.6.2',
    description='Redactor/Text block for Blanc Pages',
    long_description=open('README.rst').read(),
    url='http://www.blanctools.com/',
    maintainer='Blanc Ltd',
    maintainer_email='studio@blanc.ltd.uk',
    platforms=['any'],
    install_requires=[
        'django-redactorjs-staticfiles>=9.0.0',
    ],
    packages=find_packages(),
    package_data={'blanc_pages_redactor_block': [
        'templates/blanc_pages/blocks/*.html',
        'templates/blockadmin/blanc_pages_redactor_block/redactorblock/*.html',
    ]},
    classifiers=[
        'Environment :: Web Environment',
        'Framework :: Django',
        'License :: Other/Proprietary License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
    ],
    license='Proprietary',
)
