==========================
Blanc Pages Redactor Block
==========================

A text block which uses the Redactor editor.

Installation
============

Getting the code
----------------

The recommended way to install the Blanc Pages Redactor Block::

    $ pip install blanc-pages-redactor-block

    $ pip install django-redactorjs-staticfiles


Quick setup
-----------

.. code-block:: python 

    INSTALLED_APPS = (
        #...
        'blanc_pages_redactor_block',
        'redactorjs_staticfiles',
    )


