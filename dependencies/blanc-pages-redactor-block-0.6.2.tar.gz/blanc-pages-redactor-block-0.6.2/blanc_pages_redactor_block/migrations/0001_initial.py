# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('pages', '0004_rename_tables'),
    ]

    operations = [
        migrations.CreateModel(
            name='RedactorBlock',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True, serialize=False)),
                ('block_class', models.CharField(verbose_name='Class', max_length=50)),
                ('content', models.TextField()),
                ('content_block', models.ForeignKey(to='pages.ContentBlock', null=True, editable=False)),
            ],
            options={
                'verbose_name': 'text',
            },
        ),
    ]
