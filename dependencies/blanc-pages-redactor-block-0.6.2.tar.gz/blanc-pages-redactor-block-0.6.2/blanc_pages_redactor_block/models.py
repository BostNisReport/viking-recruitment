from blanc_pages.models.blocks import BaseBlock
from django.db import models


class BaseRedactorBlock(BaseBlock):
    block_class = models.CharField('Class', max_length=50)
    content = models.TextField()

    class Meta:
        abstract = True


class RedactorBlock(BaseRedactorBlock):
    class Meta:
        verbose_name = 'text'
