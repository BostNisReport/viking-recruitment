from blanc_pages import block_admin
from django import forms
from django.conf import settings

from .models import RedactorBlock


class BaseRedactorBlockForm(forms.ModelForm):
    class Meta:
        model = RedactorBlock
        exclude = ()


def redactor_block_form():
    class_choices = getattr(settings, 'BLANC_PAGES_REDACTOR_CHOICES', ())

    # No classes? Just return a form without them
    if not class_choices:
        class RedactorBlockForm(BaseRedactorBlockForm):
            class Meta(BaseRedactorBlockForm.Meta):
                exclude = ('block_class',)

        return RedactorBlockForm

    # The more customisable version
    class_required = getattr(settings, 'BLANC_PAGES_REDACTOR_REQUIRED', False)

    class RedactorBlockForm(BaseRedactorBlockForm):
        block_class = forms.ChoiceField(
            label='Class', choices=class_choices, required=class_required)

    return RedactorBlockForm


class RedactorBlockAdmin(block_admin.BlockModelAdmin):
    form = redactor_block_form()


block_admin.site.register(RedactorBlock, RedactorBlockAdmin)
block_admin.site.register_block(RedactorBlock, 'Common')
