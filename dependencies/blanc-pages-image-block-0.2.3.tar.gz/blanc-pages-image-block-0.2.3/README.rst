=======================
Blanc Pages Image Block
=======================

Image block with thumbnailing.
