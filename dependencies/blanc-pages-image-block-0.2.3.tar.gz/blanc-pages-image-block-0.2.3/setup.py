#!/usr/bin/env python
from setuptools import find_packages, setup


setup(
    name='blanc-pages-image-block',
    version='0.2.3',
    description='Image block for Blanc Pages',
    long_description=open('README.rst').read(),
    url='http://www.blanctools.com/',
    maintainer='Blanc Ltd',
    maintainer_email='studio@blanc.ltd.uk',
    platforms=['any'],
    install_requires=[
        'blanc-basic-assets>=0.3',
    ],
    packages=find_packages(),
    package_data={'blanc_pages_image_block': [
        'templates/blanc_pages/blocks/*.html',
    ]},
    classifiers=[
        'Environment :: Web Environment',
        'Framework :: Django',
        'License :: Other/Proprietary License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
    ],
    license='Proprietary',
)
