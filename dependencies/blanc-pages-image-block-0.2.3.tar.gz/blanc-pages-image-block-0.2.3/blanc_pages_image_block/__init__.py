
default_app_config = 'blanc_pages_image_block.apps.BlancPagesImageBlockConfig'
