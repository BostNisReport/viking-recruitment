from django.db import models
from blanc_pages.models.blocks import BaseBlock
from blanc_basic_assets.fields import AssetForeignKey


class BaseImageBlock(BaseBlock):
    image = AssetForeignKey('assets.Image', null=True, on_delete=models.PROTECT)
    description = models.CharField(max_length=200, blank=True, help_text='Used as ALT text')
    link = models.URLField(blank=True)
    new_window = models.BooleanField('Open link in new window', default=False)

    render_function = 'blanc_pages_image_block.views.imageblock'

    class Meta:
        abstract = True


class ImageBlock(BaseImageBlock):
    class Meta:
        verbose_name = 'image'
