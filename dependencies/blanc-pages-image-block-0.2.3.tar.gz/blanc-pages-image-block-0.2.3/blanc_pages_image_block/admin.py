from blanc_pages import block_admin
from .models import ImageBlock


block_admin.site.register(ImageBlock)
block_admin.site.register_block(ImageBlock, 'Common')
