from blanc_pages import get_template
from django.apps import apps
from django.core.exceptions import ImproperlyConfigured
from django.template.loader import render_to_string


if apps.is_installed('sorl.thumbnail'):
    from sorl.thumbnail import get_thumbnail
    THUMBNAIL_BACKEND = 'sorl'
elif apps.is_installed('easy_thumbnails'):
    from easy_thumbnails.files import get_thumbnailer
    THUMBNAIL_BACKEND = 'easy_thumbnails'
else:
    raise ImproperlyConfigured('Need a valid thumbnail library for image blocks.')


def imageblock(block, request, rerender, content_block, block_classes):
    css_classes = ' '.join(block_classes)

    thumb = None

    if block.image:
        # Get the block width from the layout
        template = get_template(content_block.page_version.template_name)
        block_column = template.columns[content_block.column]

        # Either use an image width, or fall back to width
        try:
            block_width = block_column['image_width']
        except KeyError:
            block_width = block_column['width']

        image = block.image

        # Resize!
        if THUMBNAIL_BACKEND == 'sorl':
            thumb = get_thumbnail(image.file, '%d' % (block_width,))
        elif THUMBNAIL_BACKEND == 'easy_thumbnails':
            thumbnailer = get_thumbnailer(image.file)
            thumb = thumbnailer.get_thumbnail({'size': (block_width, image.image_height)})

    return render_to_string('blanc_pages/blocks/%s.html' % (block._meta.model_name,), {
        'content_block': content_block,
        'css_classes': css_classes,
        'object': block,
        'thumb': thumb,
    })
