from django.apps import AppConfig


class BlancPagesImageBlockConfig(AppConfig):
    name = 'blanc_pages_image_block'
    label = 'blanc_pages_image_block'
