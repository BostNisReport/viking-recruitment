# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('blanc_pages_image_block', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='imageblock',
            name='link',
            field=models.URLField(blank=True, default=''),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='imageblock',
            name='new_window',
            field=models.BooleanField(verbose_name='Open link in new window', default=False),
            preserve_default=True,
        ),
    ]
