====================
Django Latest Tweets
====================

A Django app to store the latest tweets from Twitter.
