default_app_config = 'blanc_basic_assets.apps.BlancBasicAssetsConfig'
