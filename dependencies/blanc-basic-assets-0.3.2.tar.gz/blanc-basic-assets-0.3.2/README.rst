Blanc Basic Assets
==================

A simple Django app to give admin users a place to upload any images or files
for usage in other apps.

Installation
------------

Using pip_:

.. _pip: https://pip.pypa.io/

.. code-block:: console

    $ pip install blanc-basic-assets

Documentation
-------------

Package documentation is hosted on `Read the Docs`_, see
https://blanc-basic-assets.readthedocs.org/

.. _Read the Docs: https://readthedocs.org/
